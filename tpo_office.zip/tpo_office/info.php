<?php
	$ntc_headg_len = 200;
	$ntc_txt_len = 500;
	$ans_len = 500;
?>