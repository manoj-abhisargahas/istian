<?php
	include("request_time.php");
	include("session.php");
	include("operations.php");
	include("info.php");
	include("db_server.php");
	
	set_session($_GET["sessionid"]);
	is_old_session();
	set_empty_response();
	set_sessionid_response();
	include("db_conn.php");
	select_database("istian_db");
	include("login_validate.php");
	
	$upload_id = strtoupper(trim($_GET["upload_id"]));
	$query_index = intval($_GET["query_index"]);
	$answer = substr(trim($_GET["answer"]), 0, $ans_len);
	
	$params = [ "answer"=>$answer,
				"answer_last_edited_time"=>$request_time ];
	
	if(update_answer($upload_id, $query_index, $params)["updated"]) {
		set_success_response("true");
	}
	else {
		//ERROR: edit answer failed.
		push_error_response_id("136");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// http://localhost/istian/tpo/edit_answer.php?sessionid=studlggd-dlqatganq518r87deau653abts&request_time=1587555073&upload_id=IMRAN-1234&query_index=0&answer=it%20is%20changed.
?>