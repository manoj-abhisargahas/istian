<?php
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("istian_db");
	
	$email = trim($_GET['email']);
	$username = trim($_GET['username']);
	$pword = trim($_GET['pword']);
	
	//validating password value
	if(!isPasswordValid($pword)) {
		//ERROR: password invalid.
		push_error_response_id("103");
	}
	
	//if no errors proceeding with activating account.
	if(errors_count() == 0) {
		if(activateAccount($email, $username, $pword)) {
			set_success_response("true");
		}
		else {
			//ERROR: Account Activation failed.
			push_error_response_id("123");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/account_activate.php?email=imran@gmail.com&username=imran&pword=123456
?>