<?php
	include("operations.php");
	include("db_server.php");
	
	set_empty_response("tpo_name","");
	include("db_conn.php");
	select_database("istian_db");
	
	$email = trim($_GET['email']);
	
	//email validation.
	if(!isEmailValid($email)) {
		//ERROR: Email invalid.
		push_error_response_id("101");
	}
	
	if(errors_count() == 0) {
		$user_details = userDetails("email", "s", $email, "name");
		if(is_array($user_details)) {
			$user_details_logged = userDetailsLogged("email", "s", $email, "username");
			if(!is_array($user_details_logged)) {
				$GLOBALS["response"]["tpo_name"] = $user_details["name"];
			}
			else {
				//ERROR: Account activation already done with this email.
				push_error_response_id("105");
			}
		}
		else {
			//ERROR: your email is not associated with the college.
			push_error_response_id("104");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/account_activate_init.php?email=anirudhbala007@gmail.com
?>