<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("istian_db");
	
	$email = trim($_GET['email']);
	
	if(errors_count() == 0) {
		$otp = generateOTP();
		//pending: send OTP Email
		create_session_id("otpaccact");
		$_SESSION["otp"] = $otp;
		// echo $_SESSION["otp"];
		set_sessionid_response();
		set_success_response("true");
	}
	ECHO $_SESSION["otp"];
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/otp_send.php?email=vishnulokesh520@gmail.com
?>