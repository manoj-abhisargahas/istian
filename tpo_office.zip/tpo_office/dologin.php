<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("istian_db");
	
	$email = $_GET['email'];
	$pword = $_GET['pword'];
	
	if(!isEmailValid($email)) {
		//ERROR: email invalid.
		push_error_response_id("101");
	}
	if($pword==null || $pword=="") {
		//ERROR: password invalid.
		push_error_response_id("103");
	}
	
	//if no errors proceeding with login
	if(errors_count() == 0) {
		$user_details_logged = userDetailsLogged("email", "s", $email, "pword");
		if(is_array($user_details_logged) && 
		  !($user_details_logged['pword']=="" ||
		  $user_details_logged['pword']==null)) {
			if($pword==$user_details_logged['pword']) {
				set_success_response("true");
				
				if(session_status()===PHP_SESSION_ACTIVE)
					session_destroy();
				create_session_id("tpolggd");
				$_SESSION["login_time"] = $_SESSION["recreated_time"];
				$_SESSION['email'] = $email;
				$_SESSION['pword'] = $pword;
				set_sessionid_response();
			}
			else {
				//ERROR: Email or Password Wrong.
				push_error_response_id("120");
			}
		}
		else {
			//ERROR: No account with this email.
			push_error_response_id("121");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// localhost/istian/tpo/dologin.php?email=manojabhisargahas1@gmail.com&pword=1234567890
?>