<?php 
	// error_reporting(0);
	
	//set sessionid;
	function set_sessionid_response($sid = "") {
		$GLOBALS["response"]["sessionid"] = ($sid==""?session_id():"");
	}
	
	//set success_msg to true;
	function set_success_response($msg) {
		$GLOBALS["response"]["success_msg"] = $msg;
	}

	//push errors into array.
	function push_error_response_id($error_id) {
		array_push($GLOBALS["response"]["errors"], $error_id);
	}
	
	//set empty response.
	function set_empty_response($success_msg_key = "success_msg", $msg = "false") {
		$GLOBALS["response"] = ["sessionid"=>"", $success_msg_key=>$msg, "errors"=>[]];
	}
	
	//returns errors count.
	function errors_count() {
		return count($GLOBALS["response"]["errors"]);
	}
	
	//prints response in JSON.
	function print_response() {
		echo json_encode($GLOBALS["response"]);
	}
	
	function isEmailValid($email) {
		return preg_match("/^.+@.+\..+$/i", $email);
	}
	function isUsernameValid($username) {
		return preg_match("/^[0-9a-z\_]{5,10}$/i", $username);
	}
	function isPasswordValid($pword) {
		return preg_match("/^[0-9a-z\_\@\#\$\&]{8,16}$/i", $pword);
	}
	
	function generateOTP() {
		return rand(100000, 999999);
	}
?>