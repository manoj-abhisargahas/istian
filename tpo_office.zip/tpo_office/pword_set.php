<?php
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("istian_db");
	
	$email = trim($_POST['email']);
	$pword = trim($_POST['pword']);
	
	//validating password value
	if(!isPasswordValid($pword)) {
		//ERROR: password invalid.
		push_error_response_id("103");
	}
	
	//if no errors proceeding with updating password.
	if(errors_count() == 0) {
		if(updatePassword($email, $pword)) {
			set_success_response("true");
		}
		else {
			//ERROR: Password update failed.
			push_error_response_id("110");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/account_activate_set_pword.php?email=malapatisivakumarreddy@gmail.com&pword=123456
?>