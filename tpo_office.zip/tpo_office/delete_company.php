<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_session($_GET["sessionid"]);
	is_old_session();
	set_empty_response();
	set_sessionid_response();
	include("db_conn.php");
	select_database("istian_db");
	include("login_validate.php");
	
	$company_name = $_GET['comp_name'];
	
	if(deleteCompany($company_name)) {
		set_success_response("true");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/delete_company.php?sessionid=tpolggd-1234&comp_name=tcs
?>