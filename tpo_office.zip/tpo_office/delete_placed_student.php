<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_session($_GET["sessionid"]);
	is_old_session();
	set_empty_response();
	set_sessionid_response();
	include("db_conn.php");
	select_database("istian_db");
	include("login_validate.php");
	
	$rollno = $_GET['rollno'];
	$company_name = $_GET['comp_name'];
	
	if(deleteStudentPlacedCompany($rollno, $company_name)) {
		set_success_response("true");
	}
	else {
		// ERROR: deleting student placed company failed.
		push_error_response_id("134");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// localhost/istian/tpo/delete_placed_student.php?sessionid=tpolggd-1234&rollno=16kb1a05b5&comp_name=tcs
?>