<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_session($_GET["sessionid"]);
	is_old_session();
	set_empty_response();
	$GLOBALS["response"]["errrollnums"] = [];
	set_sessionid_response();
	include("db_conn.php");
	select_database("istian_db");
	include("login_validate.php");
	
	$company_name = $_GET['comp_name'];
	$rollnos = $_GET['rollnos'];
	
	//Company name validation.
	if($company_name==null || $company_name=="") {
		//ERROR: Company name invalid.
		push_error_response_id("116");
	}
	//student roll numbers validation.
	if(!preg_match("/^([0-9a-z]+(\,)?)+$/i", $rollnos)) {
		//ERROR: student roll numbers invalid.
		push_error_response_id("117");
	}
	
	if(errors_count() == 0) {
		if(insertPlacedStudents($rollnos, $company_name)) {
			set_success_response("true");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// localhost/istian/tpo/add_placed_students.php?sessionid=tpolggd-1234&comp_name=tcs&rollnos=16kb1a05g8,16kb1a0501
?>