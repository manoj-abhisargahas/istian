<?php
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("istian_db");
	
	$username = trim($_GET['username']);
	
	//validating username value
	if(!isUsernameValid($username)) {
		//ERROR: username invalid.
		push_error_response_id("102");
	}
	
	//if no errors proceeding with verifying username.
	if(errors_count() == 0) {
		if(!isUsernameExists($username)) {
			set_success_response("true");
		}
		else {
			//ERROR: username already exists.
			push_error_response_id("122");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/tpo/username_verify.php?username=vishnu
?>