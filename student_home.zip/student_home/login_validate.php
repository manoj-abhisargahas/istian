<?php	
	if(!login_validate()) {
		//ERROR: session logged out.
		push_error_response_id("115");
		closeDb();
		print_response();
		exit();
	}
?>