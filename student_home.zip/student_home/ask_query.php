<?php
	include("request_time.php");
	include("session.php");
	include("operations.php");
	include("info.php");
	include("db_server.php");
	
	set_session($_GET["sessionid"]);
	is_old_session();
	set_empty_response("query_index","");
	set_sessionid_response();
	include("db_conn.php");
	select_database("digital_notice_db");
	// include("login_validate.php");
	
	$_SESSION["email"] = "anirudhbala007@gmail.com";
	$upload_id = strtoupper(trim($_GET["upload_id"]));
	$query = substr(trim($_GET["query"]), 0, $query_len);
	$ud = userDetails("email", "s", $_SESSION["email"], "rollno");
	$rollno = $ud["rollno"];
	
	select_database("istian_db");
	$query_index = insert_query_with_next_max_query_index($rollno, $upload_id, $query, $request_time);
	if($query_index!=null) {
		$GLOBALS["response"]["query_index"] = $query_index;
	}
	else {
		//ERROR: Query Not Inserted.
		push_error_response_id("124");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//http://localhost/istian/student/ask_query.php?sessionid=studlggd-dlqatganq518r87deau653abts&request_time=1587541060&upload_id=IMRAN-1234&query=what%20is%20it?
?>