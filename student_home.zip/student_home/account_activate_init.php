<?php
	include("operations.php");
	include("db_server.php");
	
	set_empty_response("student_name","");
	$GLOBALS["response"]["student_rollno"] = "";
	include("db_conn.php");
	select_database("digital_notice_db");
	
	$email = trim($_GET['email']);
	
	//email validation.
	if(!isEmailValid($email)) {
		//ERROR: Email invalid.
		push_error_response_id("101");
	}
	
	if(errors_count() == 0) {
		$user_details = userDetails("email", "s", $email, "name", "rollno", "pword");
		if(is_array($user_details)) {
			if(!is_account_activated($user_details)) {
				$GLOBALS["response"]["student_name"] = $user_details["name"];
				$GLOBALS["response"]["student_rollno"] = $user_details["rollno"];
			}
			else {
				//ERROR: Account activation already done with this email.
				push_error_response_id("105");
			}
		}
		else {
			//ERROR: your email is not associated with the college.
			push_error_response_id("104");
		}
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// localhost/istian/student/account_activate_init.php?email=anirudhbala007@gmail.com
?>