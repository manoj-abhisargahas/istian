<?php
	$sess_recreate_id_time = 60 * 5;
	$otp_max_active_time	= 60 * 10;
	
	function set_session($sessionid = "") {
		ini_set('session.use_strict_mode', 0);
		//get session_id if sended-by-user or setted.
		if(!($sessionid==""))
			session_id($sessionid);
		
		//start session.
		session_start();
	}
	
	function is_old_session() {
		$prefix = explode("-", session_id())[0];
		
		//for login session:
		if($prefix=="tpolggd") {
			//if recreated_time is old (>15min) recreate session_id
			//but without losing present session data.
			if(!isset($_SESSION["recreated_time"]) ||
			  empty($_SESSION["recreated_time"])) {
				session_destroy();
			}
			else if(time()-$_SESSION["recreated_time"] > $GLOBALS["sess_recreate_id_time"]) {
				create_session_id("studlggd");
			}
		}
	}
	
	function create_session_id($prefix = "") {
		//has to regenerate new_session_id if session_status = active.
		if(session_status()!==PHP_SESSION_ACTIVE)
			session_start();
		
		//store present_session values.
		$sess_arr = $_SESSION;
		//ends the present session but save old data.
		session_commit();
		
		ini_set('session.use_strict_mode', 0);
		$prefix.=($prefix==""?"":"-");
		session_id(session_create_id($prefix));
		session_start();
		
		//restore present_session(replaced with new session_id) values.
		$_SESSION = $sess_arr;
		$_SESSION["recreated_time"] = time();
	}
	
	function is_session_expired($time) {
		//checking expiry time for link.
		if(!isset($_SESSION["recreated_time"]) ||
		  empty($_SESSION["recreated_time"]) ||
		 (time()-$_SESSION["recreated_time"] > $time)) {
			return true;
		}
		return false;
	}
?>