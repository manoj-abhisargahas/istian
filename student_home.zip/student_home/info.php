<?php
	$query_len = 500;
?>