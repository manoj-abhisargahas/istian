<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("digital_notice_db");
	
	$email = trim($_GET['email']);
	
	if(errors_count() == 0) {
		$otp = generateOTP();
		//pending: send OTP Email
		create_session_id("otpaccact");
		$_SESSION["otp"] = $otp;
		// echo $_SESSION["otp"];
		set_sessionid_response();
		set_success_response("true");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/student/account_activate_send_otp.php?email=vishnulokesh520@gmail.com
?>