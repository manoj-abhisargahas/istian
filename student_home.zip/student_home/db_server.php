<?php
	$mysqli = "";
	
	function connectDb() {
		$GLOBALS["mysqli"] = new mysqli("localhost", "root", "");
		return ($GLOBALS["mysqli"]->connect_errno==0);
	}
	
	//select database.
	function select_database($db_name) {
		$GLOBALS['mysqli']->select_db($db_name);
	}
	
	// closes database connection.
	function closeDb() {
		$GLOBALS["mysqli"]->close();
	}
	
	//fetch result as association array for statement object.
	function statement_fetch_assoc($stmt) {
		if($stmt->num_rows > 0) {
			$result = array();
			$params = array();
			$fields = $stmt->result_metadata();
			while($field = $fields->fetch_field()) {
				$params[] = &$result[$field->name];
			}	
			$stmt->bind_result(...$params);
			// call_user_func_array(array($stmt, "bind_result"), $params);
			if($stmt->fetch())
				return $result;
			else
				return null;
		}
		
		return null;
	}
	
	// gets user details from database by $cond_col.
	function userDetails($cond_col, $col_type, $col_value, ...$details) {
		$user_details = null;
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$details = implode(", ", $details);
		$query = "select ".$details." from student where ".$cond_col."=?";
		$stmt->prepare($query);
		$stmt->bind_param($col_type, $col_value);
		if($stmt->execute()) {
			$stmt->store_result();
			if(($no_of_users = $stmt->num_rows) == 1) {
				$user_details = statement_fetch_assoc($stmt);
			}
			$stmt->free_result();
		}
		$stmt->close();
		
		return $user_details;
	}
	
	// checks if account activated or not.
	function is_account_activated($user_details) {
		if($user_details["pword"]==null || $user_details["pword"]=="") {
			return false;
		}
		return true;
	}
	
	// validates login.
	function login_validate() {
		$validate = false;
		
		//if no login credentials are there in present session, redirects to login.
		if(isset($_SESSION['email']) && isset($_SESSION['pword'])) {
			$email = $_SESSION['email'];
			$pword = $_SESSION['pword'];
			
			//if login fails, redirects to login.
			$user_details = userDetails($email);
			if(is_array($user_details)) {
				if($pword==$user_details['pword']) {
					$validate = true;
				}
			}
		}
		
		return $validate;
	}
	
	//updates password
	function updatePassword($email, $pword) {
		$is_updated = Array("updated"=>null, "affected_rows"=>0);
		
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$query = "UPDATE student SET
					pword=?
					WHERE email = ?";
		$stmt->prepare($query);
		$stmt->bind_param("ss", $pword, $email);
		$is_updated["updated"] = $stmt->execute();
		$is_updated["affected_rows"] = $stmt->affected_rows;
		$stmt->close();
		
		return $is_updated;
	}
	
	//mail otp to client.
	function mailOTP($email, $otp) {
		$is_mailed = false;
		$subject = "Student Signup OTP";
		$message = "OTP: ".$otp;
		if(mail("$email", $subject, $message)) {
			$is_mailed = true;
		}
		else {
			//ERROR: email is not accepted by delivery system.
			push_error_response_id("106");
		}
		return $is_mailed;
	}
	
	// get student placed companies.
	function getStudentPlacedCompanies($rollno) {
		$placed_companies = [];
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$query = "select placed_company from students_placed where student_rollno=?";
		$stmt->prepare($query);
		$stmt->bind_param("s", $rollno);
		if($stmt->execute()) {
			$stmt->store_result();
			$stmt->bind_result($comp_name);
			while($stmt->fetch()) {
				array_push($placed_companies, $comp_name);
			}
			$stmt->free_result();
		}
		$stmt->close();
		return $placed_companies;
	}
	
	// gets student full details.
	function getStudentDetails($rollno) {
		$student = [];
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$query = "select name, rollno, present_year, branch, section, cgpa, backlogs, batch, email from student where rollno=?";
		$stmt->prepare($query);
		$stmt->bind_param("s", $rollno);
		if($stmt->execute()) {
			$stmt->store_result();
			$stmt->bind_result($student['name'], 
							$student['rollno'], 
							$student['present_year'], 
							$student['branch'], 
							$student['section'], 
							$student['cgpa'], 
							$student['backlogs'], 
							$student['batch'], 
							$student['email']);
			$stmt->fetch();
			$stmt->free_result();
		}
		$stmt->close();
		return $student;
	}
	
	// insert student asked query.
	function insert_query_with_next_max_query_index($student_rollno, $upload_id, $asked_query, $query_time) {
		$next_max_query_index = null;
		
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$query = "SELECT insert_query_with_next_max_query_index(?, ?, ?, ?) as next_max_query_index;";
		$stmt->prepare($query);
		$stmt->bind_param("sssi", $upload_id, $student_rollno, $asked_query, $query_time);
		
		if($stmt->execute()) {
			$stmt->store_result();
			$stmt->bind_result($next_max_query_index);
			$stmt->fetch();
		}
		$stmt->close();
		
		return $next_max_query_index;
	}
	
	// delete student asked query.
	function delete_query($upload_id, $query_index) {
		$deleted = false;
		
		$stmt = $GLOBALS['mysqli']->stmt_init();
		$query = "delete from queries_answers where upload_id = ? and query_index = ?";
		$stmt->prepare($query);
		$stmt->bind_param("ss", $upload_id, $query_index);
		if($stmt->execute()) {
			$deleted = true;
		}
		$stmt->close();
		
		return $deleted;
	}
?>