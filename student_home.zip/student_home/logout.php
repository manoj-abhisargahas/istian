<?php
	include("session.php");
	include("operations.php");
	
	set_session($_GET['sessionid']);
	session_destroy();
	set_empty_response();
	set_success_response("true");
	
	print_response();
	
	// localhost/istian/student/logout.php?sessionid=studlggd-12345678
?>