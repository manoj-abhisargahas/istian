<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_session($_GET['sessionid']);
	is_old_session();
	set_empty_response();
	set_sessionid_response();
	include("db_conn.php");
	select_database("digital_notice_db");
	
	if(login_validate()) {
		set_success_response("true");
	}
	else {
		//ERROR: session loggedout.
		push_error_response_id("115");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	// localhost/istian/student/isloggedin.php?sessionid=studlggd-1234
?>