<?php
	include("session.php");
	include("operations.php");
	include("db_server.php");
	
	set_empty_response();
	include("db_conn.php");
	select_database("digital_notice_db");
	
	set_session($_POST['sessionid']);
	//checking if OTP expired or not.
	if(!is_session_expired($otp_max_active_time)) {
		$otp = trim($_POST['otp']);
		
		//checking if OTP correct or not.
		if($otp==$_SESSION["otp"]) {
			set_success_response("true");
			session_destroy();
		}
		else {
			//ERROR: Wrong OTP.
			push_error_response_id("107");
		}
	}
	else {
		//ERROR: OTP Expired.
		session_destroy();
		push_error_response_id("109");
	}
	
	//closing Database connection.
	closeDb();
	
	print_response();
	
	//localhost/istian/student/account_activate_verify_otp.php?sessionid=otpaccact-ax&otp=123456
?>