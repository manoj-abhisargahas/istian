<?php
	include("session.php");
	include("info.php");
	include("db_server.php");
	
	//getting rnpid and setting as sessionid.
	set_session($_GET['rnpid']);
	is_link_expired();
	$conn = ConnectDb();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Digital Notice</title>
		<link href="../v.ico" rel="icon">
		<link href="../css/style.css" rel="stylesheet">
		<link href="../css/responsive_style.css" rel="stylesheet">
		<script src="../js/js.js"></script>
		<script src="../js/reset_new_pword_link.js"></script>
		<meta name="viewport" content="user-scalable=no, initial-scale=1, minimum-scale=1, maximum-scale=1, width=device-width, height=device-height"/>
		<meta name="theme-color" content="#eee" />
		<meta name="msapplication-navbutton-color" content="#eee" />
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta name="apple-mobile-web-app-status-bar-style" content="#eee" />
	</head>
	<body>
		<div id="main-body">
			<header>
				<title>Digital Notice</title>
			</header>
			<div id="account-actions">
				<div id="app-name-head">
					<span id="app-name-part-digital_notice">
						<span>D</span><span>i</span><span>g</span><span>i</span><span>t</span><span>a</span><span>l</span>
						<span id="app-name-part-notice">Notice</span>
					</span>
				</div>
				<div id="account-actions-main-body">
					<h1 id="account-actions-heading">Reset New Password</h1>
					<form id="reset_new_pword-account-form" onsubmit="return resetNewPword_validate()" method="POST" action="reset_new_pword.php">
						<div id="error-indicate"></div>
						<input id="reset_new_pword-pword" name="reset_new_pword-pword" type="text" name="" placeholder="New Password"/>
						<div id="error-indicate-reset_new_pword-pword"></div>
						<input id="reset_new_pword-retype_pword" type="text" placeholder="Retype Password"/>
						<div id="error-indicate-reset_new_pword-retype_pword"></div>
						<input id="rnpid" name="rnpid" type="hidden" value="<?php echo $_SESSION["rnpid"]?>"/>
						<div id="account-actions-info">
							<span class="help-symbol">?</span>Password must contain 8 to 16 characters:
							<span class="padding-symbol">&nbsp;</span>Alphabets, Digits, Symbols<span class="symbols">_@#$& </span>
						</div>
						<div class="account-actions-switch-options">
							<input id="reset_new_pword-button" type="submit" value="Done"/>
						</div>
					</form>
				</div>
			</div>
			<!--SHADE BODY FOR DIALOGS-->
			<div id="shade-body"></div>
		</div>
		<?php
			if(!$conn) {
				echo "<script>
					invokeDialog(\"cancel\", \"".$errors_list["100"]."\", \"cancel\", \"cancelDialog()\", \"null\", \"null\");
				</script>";
			}
			else {
				closeDb();
			}
			
			//indicating: ERROR:Password update failed.
			if(isset($_SESSION['rnperr']) && $_SESSION['rnperr']=="113") {
				echo "<script>
					msgIndicate(\"error-indicate\", true, \"".$errors_list[$_SESSION["rnperr"]]."\");
				</script>";
				unset($_SESSION['rnperr']);
			}
			
			//indicating: ERROR:reset_new_pword-email invalid
			if(isset($_SESSION['rnppworderr']) && $_SESSION['rnppworderr']=="115") {
				echo "<script>
					msgIndicate(\"error-indicate-reset_new_pword-pword\", true, \"".$errors_list[$_SESSION["rnppworderr"]]."\");
					textfieldErrorShow(\"reset_new_pword-pword\", true);
				</script>";
				unset($_SESSION['rnppworderr']);
			}
		?>
	</body>
</html>