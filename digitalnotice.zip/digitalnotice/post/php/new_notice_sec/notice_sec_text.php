<!--NOTICE TEXT-->
<label id="notice-sec-text" for="notice_text_field">
	<textarea id="notice_text_field" rows="1" placeholder="Write something about the notice.">Wish you a happy new year and a happy life.</textarea>
</label>
<label class="text-count" for="notice_text_field">
	<span id="n_t_f-text-count">0</span>/<span id="n_t_f-total-text-count"><?php echo $ntc_txt_len ?></span>
</label>