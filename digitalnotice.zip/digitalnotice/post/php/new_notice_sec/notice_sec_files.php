<!--NOTICE FILES-->
<div id="notice-sec-files">
	<div id="total-attached-files-info">
		<span id="t-a-f-size" class="">0 B</span>
		<span id="t-a-f-count">(0)</span>
	</div>
	<div id="uploaded_files"></div>
</div>