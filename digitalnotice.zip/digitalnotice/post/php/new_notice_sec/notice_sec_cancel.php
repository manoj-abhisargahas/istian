<!--NOTICE CANCEL-->
<div id="cancel-notice-sec">
	<div id="notice-post-body-cancel" onclick="cancelNewPostBox(), deleteFilesFromServer_Ajax()">
		<span class="wrong_icon">+</span>
	</div>
	<div class="new_notice_text">New Notice</div>
</div>