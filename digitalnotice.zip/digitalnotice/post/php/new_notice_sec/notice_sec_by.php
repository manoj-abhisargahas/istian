<!--NOTICE BY-->
<div id="notice-sec-by" style="display:none">
	<span id="sec-heading-notice_by">Notice By:</span><span id="notice-by"><?php echo(strtoupper($_SESSION['notice_by']));?></span>
</div>