<!--NOTICE IMAGE-->
<div id="notice-sec-image">
	<div id="notice-image-align-box">
		<div id="notice_image_button_adj">
			<input id="notice_image_button" name="notice_image_button" 
			type="file" accept="image/*" 
			oninput="loadNoticeImage(event)"/>
			<label id="label-notice_image_button" for="notice_image_button">
				<?php include("html/rectangle.html"); ?>
				<div id="notice_image_button_icon" ></div>
				<span id="notice_image_button_name">Upload Notice Image</span>
			</label>
		</div>
		<div id="notice_image_viewer"><img id="notice_image"/></div>
		<div id="notice_image_adj"></div>
		<progress id="progress-uploaded_image"></progress>
	</div>
	<div id="notice_image_manipulate_buttons" style="height:0">
		<div id="align-image-sec">
			<div id="align-image-head">Align</div>
			<label id="label-align_image-top" onclick="alignImage('t')">
				<?php include("../images/align_image_top_icon.svg"); ?>
			</label>
			<label id="label-align_image-center" onclick="alignImage('c')">
				<?php include("../images/align_image_center_icon.svg"); ?>
			</label>
			<label id="label-align_image-bottom" onclick="alignImage('b')">
				<?php include("../images/align_image_bottom_icon.svg"); ?>
			</label>
		</div>
		<div id="image-manipulate-sec">
			<label id="label-change_notice_image_button" for="notice_image_button">
				<div id="change_notice_image_button_icon"></div>
			</label>

			<label id="label-delete_notice_image_button" onclick="deleteImageFromServer_Ajax(img_file_indx)">
				<div id="delete_notice_image_button_icon"></div>
			</label>
		</div>
	</div>
</div>