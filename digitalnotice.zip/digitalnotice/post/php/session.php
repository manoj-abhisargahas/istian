<?php
	/* $sess_cookie_expire_time = 60 * 15;
	$sess_login_expire_time	= 60 * 10;
	$sess_recreate_id_time = 60 * 5;
	$sess_max_inactive_time	= 60 * 5; */
	
	$sess_cookie_expire_time = 60 * 240;
	$sess_login_expire_time	= 60 * 160;
	$sess_recreate_id_time = 60 * 80;
	$sess_max_inactive_time	= 60 * 80;
	
	function get_session_cookie() {
		$sessionid = "";
		
		if(isset($_COOKIE['sessionid']) &&
		!empty($_COOKIE["sessionid"])) {
			$sessionid = $_COOKIE['sessionid'];
		}
		
		return $sessionid;
	}
	
	function set_session_cookie() {
		//setting session_id cookie with time:20min.
		setcookie("PHPSESSID", session_id(), time()+$GLOBALS["sess_cookie_expire_time"], "/");
	}
	
	function set_session($sessionid = "") {
		ini_set('session.use_strict_mode', 0);
		//get session_id if sended-by-user or setted.
		if(!($sessionid==""))
			session_id($sessionid);
		
		//start session.
		session_start();
		
		$prefix = explode("-", session_id())[0];
		
		//setting last_active_time for new sessions,
		//updating last_active_time for logged sessions.
		if(!isset($_SESSION["last_active_time"]) || 
		     empty($_SESSION["last_active_time"]) ||
		          ($prefix=="dntc")) {
			$_SESSION["last_active_time"] = time();
		}
	}
	
	function is_old_session() {
		$prefix = explode("-", session_id())[0];
		
		//for login session:
		if($prefix=="dntc") {
			//if login_time is old (>1hour) destroy and start new session.
			if(!isset($_SESSION["login_time"]) ||
			  empty($_SESSION["login_time"]) ||
			  (time()-$_SESSION["login_time"] > $GLOBALS["sess_login_expire_time"])) {
				logout();
			}
				
			//if recreated_time is old (>15min) recreate session_id
			//but without losing present session data.
			if(!isset($_SESSION["recreated_time"]) ||
			  empty($_SESSION["recreated_time"])) {
				logout();
			}
			else if(time()-$_SESSION["recreated_time"] > $GLOBALS["sess_recreate_id_time"]) {
				create_logged_session_id("dntc");
			}
		}
		
		//if any session inactive_time is old (>15min) destroy and start new session.
		if(isset($_SESSION["last_active_time"]) &&
		  !empty($_SESSION["last_active_time"]) &&
		 (time()-$_SESSION["last_active_time"] > $GLOBALS["sess_max_inactive_time"])) {
			logout();
		}
	}
	
	function create_logged_session_id($prefix = "") {
		//has to regenerate new_session_id if session_status = active.
		if(session_status()!==PHP_SESSION_ACTIVE)
			session_start();
		
		//store present_session values.
		$sess_arr = $_SESSION;
		//ends the present session but save old data.
		session_commit();
		
		ini_set('session.use_strict_mode', 0);
		$prefix.=($prefix==""?"":"-");
		session_id(session_create_id($prefix));
		session_start();
		
		//restore present_session(replaced with new session_id) values.
		$_SESSION = $sess_arr;
		$_SESSION["recreated_time"] = time();
	}
	
	function is_link_expired() {
		//checking expiry time for link.
		if(!isset($_SESSION["recreated_time"]) ||
		  empty($_SESSION["recreated_time"]) ||
		 (time()-$_SESSION["recreated_time"] > 60*5)) {
			logout();
		}
		
		//if link-expired redirecting to "link_expired" page.
		if(!isset($_SESSION['assoc_email']) || $_SESSION['assoc_email']==null || $_SESSION['assoc_email']=="") {
			header("location:link_expired.php");
			exit();
		}
	}
	
	function logout() {
		session_destroy();
		session_id("");
		session_start();
	}
?>