var max_width_700px = window.matchMedia("(max-width: 700px)");
max_width_700px.addListener(documentElementsVisibility);

function documentElementsVisibility(event) {
	if(event.matches) {
	}
	else {
	}
}