<?php
	//setting up connection to database.
	$mysqli = new mysqli("localhost", "root", "", "digital_notice_db");
	if($mysqli->connect_errno) {
		push_error_msg("Connection error.");
		print_response();
		exit();
	}
	
	//set success_msg to true;
	function set_success_msg($msg) {
		$GLOBALS["response"]['success_msg'] = $msg;
	}
	
	//push errors into array.
	function push_error_msg($error_msg) {
		array_push($GLOBALS["response"]["errors"], $error_msg);
	}
	
	//prints response in JSON.
	function print_response() {
		echo json_encode($GLOBALS["response"]);
	}
	
	function category($notice_by) {
		if($notice_by=="COLLEGE" || $notice_by=="LIBRARY")
			return 1;
		if($notice_by=="CE"||$notice_by=="CSE"||$notice_by=="ECE"||$notice_by=="EEE"||$notice_by=="IT"||$notice_by=="ME")
			return 2;
	}
?>