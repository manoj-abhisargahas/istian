<!DOCTYPE html>
<html>
	<head>
		<title>Digital Notice</title>
		<link href="v.ico" rel="icon">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive_style.css" rel="stylesheet">
		<script src="js/date.js"></script>
		<script src="js/js.js"></script>
		<script src="js/getNoticesByNames.js"></script>
		<script src="js/getNoticesBy.js"></script>
		<meta name="viewport" content="user-scalable=no, initial-scale=1, minimum-scale=1, maximum-scale=1, width=device-width, height=device-height"/>
		<meta name="theme-color" content="rgb(0, 116, 167)"/>
		<meta name="msapplication-navbuttton-color" content="rgb(0, 116, 167)"/>
		<meta name="apple-mobile-web-app-capable" content="yes"/>
		<meta name="apple-mobile-web-app-status-bar-style" content="rgb(0, 116, 167)"/>
	</head>
	<body>
		<div id="main-body">
			<header>
				<div class="list-notices-by-holder">
					<div id="list-notices-by"></div>
				</div>
			</header>
			<div id="digital-notices-body">
			</div>
		</div>
	</body>
</html>