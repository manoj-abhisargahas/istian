<!DOCTYPE html>
<html>
	<head>
		<title>Digital Notice</title>
		<link href="v.ico" rel="icon">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive_style.css" rel="stylesheet">
		<script src="js/date.js"></script>
		<script src="js/js.js"></script>
		<script src="js/getNoticesByNames.js"></script>
		<script src="js/getNoticesBy.js"></script>
		<meta name="viewport" content="user-scalable=no, initial-scale=1, minimum-scale=1, maximum-scale=1, width=device-width, height=device-height"/>
		<meta name="theme-color" content="#f9f9f9"/>
		<meta name="msapplication-navbuttton-color" content="#f9f9f9"/>
		<meta name="apple-mobile-web-app-capable" content="yes"/>
		<meta name="apple-mobile-web-app-status-bar-style" content="#f9f9f9"/>
	</head>
	<body>
		<header id="header">
			<div class="app-name-holder" id="app_name_holder">
				<a id="app-name" href="">
					<span id="app-name-part-digital_notice">
						<span>D</span><span>i</span><span>g</span><span>i</span><span>t</span><span>a</span><span>l</span>
						<span id="app-name-part-notice">Notice</span>
					</span>
				</a>
			</div>
			<div class="list-notices-by-holder">
				<div id="list-notices-by"></div>
			</div>
		</header>
		<div id="notices-view-sec">
			<div id="notices-view-body"></div>
		</div>
	</body>
</html>